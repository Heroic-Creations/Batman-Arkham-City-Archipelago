ScriptHost:LoadScript("scripts/items_import.lua")
Tracker:AddMaps("maps/maps.json")
ScriptHost:LoadScript("scripts/layouts_import.lua")
ScriptHost:LoadScript("scripts/locations_import.lua")

if PopVersion and PopVersion >= "0.18.0" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
end
