-- Archipelago autotracking for Batman: Arkham City

ScriptHost:LoadScript("scripts/autotracking/item_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/location_mapping.lua")

CUR_INDEX = -1

function onClear(slot_data)
    CUR_INDEX = -1

    -- reset every tracked item
    for _, v in pairs(ITEM_MAPPING) do
        local obj = Tracker:FindObjectForCode(v[1])
        if obj then
            if v[2] == "toggle" then
                obj.Active = false
            elseif v[2] == "progressive" then
                obj.CurrentStage = 0
                obj.Active = false
            elseif v[2] == "consumable" then
                obj.AcquiredCount = 0
            end
        end
    end

    -- reset every location
    for _, v in pairs(LOCATION_MAPPING) do
        local obj = Tracker:FindObjectForCode(v[1])
        if obj then
            if v[1]:sub(1, 1) == "@" then
                obj.AvailableChestCount = obj.ChestCount
            else
                obj.Active = false
            end
        end
    end
end

function onItem(index, item_id, item_name, player_number)
    if index <= CUR_INDEX then
        return
    end
    CUR_INDEX = index

    local mapping = ITEM_MAPPING[item_id]
    if not mapping then
        return
    end

    local obj = Tracker:FindObjectForCode(mapping[1])
    if not obj then
        return
    end

    if mapping[2] == "toggle" then
        obj.Active = true
    elseif mapping[2] == "progressive" then
        obj.CurrentStage = obj.CurrentStage + 1
        obj.Active = true
    elseif mapping[2] == "consumable" then
        obj.AcquiredCount = obj.AcquiredCount + 1
    end
end

function onLocation(location_id, location_name)
    local mapping = LOCATION_MAPPING[location_id]
    if not mapping then
        return
    end
    local obj = Tracker:FindObjectForCode(mapping[1])
    if obj then
        if mapping[1]:sub(1, 1) == "@" then
            obj.AvailableChestCount = obj.AvailableChestCount - 1
        else
            obj.Active = true
        end
    end
end

Archipelago:AddClearHandler("clear handler", onClear)
Archipelago:AddItemHandler("item handler", onItem)
Archipelago:AddLocationHandler("location handler", onLocation)
